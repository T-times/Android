package com.tady.directory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    MyHelper MyHelper;
    private EditText mEtName;
    private EditText mEtPhone;
    private TextView mTvShow;
    private Button mBtnAdd;
    private Button mBtnQuery;
    private Button mBtnUpdate;
    private Button mBtnDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MyHelper = new MyHelper(this);
        init();
    }

    private void init() {
        mEtName = (EditText) findViewById(R.id.et_name);
        mEtPhone = (EditText) findViewById(R.id.et_phone);
        mTvShow = (TextView) findViewById(R.id.tv_show);
        mBtnAdd = (Button) findViewById(R.id.btn_add);
        mBtnUpdate = (Button) findViewById(R.id.btn_update);
        mBtnDelete = (Button) findViewById(R.id.btn_delete);
        mBtnQuery = (Button) findViewById(R.id.btn_query);
        mBtnAdd.setOnClickListener(this);
        mBtnUpdate.setOnClickListener(this);
        mBtnDelete.setOnClickListener(this);
        mBtnQuery.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String name;
        String phone;
        SQLiteDatabase db;
        ContentValues values;
        db = MyHelper.getWritableDatabase();//获取可读写SQLiteDatabase对象
        switch (v.getId()) {
//            添加数据
            case R.id.btn_add:
                name = mEtName.getText().toString();
                phone = mEtPhone.getText().toString();
                values = new ContentValues(); //创建ContentValues对象
                values.put("name", name);
                values.put("phone", phone);
                db.insert("information", null, values);
                Toast.makeText(this, "信息已添加", Toast.LENGTH_SHORT).show();
                db.close();
                break;
            case R.id.btn_query:
                Cursor cursor = db.query("information", null, null, null, null, null, null);
                if (cursor.getCount() == 0) {
                    mTvShow.setText("");
                    Toast.makeText(this, "没有数据", Toast.LENGTH_SHORT).show();
                }else{
                     cursor.moveToFirst();
                    mTvShow.setText("name: " + cursor.getString(1) + "; Tel : " + cursor.getString(2));
                }
                while (cursor.moveToNext()) {
                     mTvShow.setText("\n"+"name: " + cursor.getString(1) + "; Tel : " + cursor.getString(2));
                }
                cursor.close();
                db.close();
                break;
            case R.id.btn_update:
                values = new ContentValues();
                values.put("phone", phone = mEtPhone.getText().toString());
                db.update("information", values, "name=?", new String[]{mEtName.getText().toString()});
                Toast.makeText(this, "信息已修改", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btn_delete:
                db.delete("information", null, null);
                Toast.makeText(this, "信息已删除", Toast.LENGTH_SHORT).show();
                db.close();
                break;
        }
    }

    private class MyHelper extends SQLiteOpenHelper {
        public MyHelper(Context context) {
            super(context, "android.db", null, 1);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE information(_id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR(20), phone VARCHAR(20))");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }
    }
}
